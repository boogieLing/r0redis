import os


os.environ['APP_ENV'] = 'test'
